// Sample Data (You can use a JSON file or a database in a real app)
let books = [
    { title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: "Fiction", year: 1925, status: "Available" },
    { title: "To Kill a Mockingbird", author: "Harper Lee", genre: "Fiction", year: 1960, status: "Available" }
];

// Function to Display Books
function displayBooks(bookList) {
    const bookListDiv = document.getElementById('book-list');
    bookListDiv.innerHTML = ''; // Clear the list before rendering

    bookList.forEach((book, index) => {
        const bookDiv = document.createElement('div');
        bookDiv.classList.add('book-item');

        bookDiv.innerHTML = `
            <h3>${book.title}</h3>
            <p>Author: ${book.author}</p>
            <p>Genre: ${book.genre}</p>
            <p>Year: ${book.year}</p>
            <p>Status: ${book.status}</p>
            ${book.status === 'Available' ? `<button onclick="borrowBook(${index})">Borrow</button>` : ''}
        `;

        bookListDiv.appendChild(bookDiv);
    });
}

// Function to Search Books
function searchBooks() {
    const query = document.getElementById('search-bar').value.toLowerCase();
    const filteredBooks = books.filter(book => 
        book.title.toLowerCase().includes(query) ||
        book.author.toLowerCase().includes(query) ||
        book.genre.toLowerCase().includes(query)
    );
    displayBooks(filteredBooks);
}

// Function to Add a New Book
function addBook() {
    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const genre = document.getElementById('genre').value;
    const year = document.getElementById('year').value;

    if (title && author && genre && year) {
        const newBook = {
            title,
            author,
            genre,
            year: parseInt(year),
            status: 'Available'
        };
        books.push(newBook);
        displayBooks(books);

        // Clear form fields
        document.getElementById('title').value = '';
        document.getElementById('author').value = '';
        document.getElementById('genre').value = '';
        document.getElementById('year').value = '';
    } else {
        alert('Please fill in all fields');
    }
}

// Function to Borrow a Book
function borrowBook(index) {
    books[index].status = 'Borrowed';
    displayBooks(books);
}

// Initial display of books
displayBooks(books);
